# Dual Robotic Arm Autonomous Chess System — M6 Week 1 simulation foundation
ROS 2 Jazzy · Ubuntu 24.04 · Gazebo Harmonic. Owner: M6 (Youssef Sameh).

**All arm/board numbers are PLACEHOLDERS** (not in the project PDFs). Edit only:
`dual_chess_description/urdf/arm/arm_params_placeholder.xacro` and `.../board/board_params_placeholder.xacro`.

## Contents
| Package | What |
|---|---|
| `dual_chess_description` | Xacro model (board + robot1 + robot2), RViz config, `display.launch.py`, structure checker |
| `dual_chess_gazebo` | `chess_world.sdf`, ROS-Gazebo bridge config, `gazebo.launch.py` |
| `dual_chess_bringup` | `simulation.launch.py` (Gazebo + RViz) |
Docs: `docs/00_week1_checklist.md`, `01_research.md`, `02_architecture.md`, `03_verification_troubleshooting.md`, `WEEK1_M6_REPORT.md`.

## 1. Install dependencies (once)
```bash
sudo apt update
sudo apt install -y ros-jazzy-desktop ros-jazzy-ros-gz ros-jazzy-xacro \
  ros-jazzy-robot-state-publisher ros-jazzy-joint-state-publisher ros-jazzy-joint-state-publisher-gui \
  ros-jazzy-rviz2 ros-jazzy-tf2-tools liburdfdom-tools python3-colcon-common-extensions
```
(If ROS 2 Jazzy is not installed yet: follow https://docs.ros.org/en/jazzy/Installation/Ubuntu-Install-Debs.html first.)

## 2. Create the workspace
```bash
mkdir -p ~/dual_chess_ws
unzip dual_chess_ws.zip -d ~/          # creates ~/dual_chess_ws/src, docs, README
# (or copy the src/ and docs/ folders into ~/dual_chess_ws yourself)
cd ~/dual_chess_ws
source /opt/ros/jazzy/setup.bash
colcon build --symlink-install
source install/setup.bash              # repeat in every new terminal
```

## 3. Run
```bash
# A) RViz only (fake joints, sliders)
ros2 launch dual_chess_description display.launch.py
#    options: gui:=false  rviz:=false  robot2_enabled:=false  use_meshes:=true

# B) Gazebo only
ros2 launch dual_chess_gazebo gazebo.launch.py
#    options: gz_args:="-r -s" (headless)  spawn_delay:=6.0

# C) Gazebo + RViz together
ros2 launch dual_chess_bringup simulation.launch.py

# Move a joint in Gazebo (radians, within placeholder limits)
ros2 topic pub --once /robot1/joint1/cmd_pos std_msgs/msg/Float64 "{data: 0.6}"
ros2 topic pub --once /robot2/joint2/cmd_pos std_msgs/msg/Float64 "{data: 0.4}"
```

## 4. Verify
See `docs/03_verification_troubleshooting.md`. Quick version:
```bash
xacro $(ros2 pkg prefix --share dual_chess_description)/urdf/dual_chess.urdf.xacro > /tmp/dual_chess.urdf
check_urdf /tmp/dual_chess.urdf
ros2 run dual_chess_description check_urdf_structure.py /tmp/dual_chess.urdf
```
